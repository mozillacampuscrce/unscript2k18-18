<?php
include_once('client/includes/header.php');
?>
<div class="container" id="main-container" style="width:400px">
            <ul class="nav nav-tabs">
                <h3><li class="active"><a data-toggle="tab" href="#home">Sign In</a></li></h3>
            </ul>   

              <div class="tab-content">
                <div id="home" class="tab-pane fade in active">
                    <?php
                    $loginError="";
$SI="active";
$SO="";
if(isset($_POST['login'])){
   
    include('client/includes/functions.php');
    //create variable to store HTML data
    //wrap data with validating function
    //$formUser = $_POST['username'];
    $formUser= validateFormData($_POST['email']);
    $formPass= validatePassword($_POST['password']);
    //connect to database
    include("client/includes/connection.php");
    
    
    //create a SQL query
    $query="select email, password from teacher where email='$formUser'";
    
    //store the result
    
    $result=mysqli_query($conn,$query);
    
    //verify if result is returned 
    
    if(mysqli_num_rows($result)>0){
        //there are some rows
        if(mysqli_num_rows($result)>1){
            $loginError="<div class='alert alert-danger'> There is some issue in database! Please contact 
            Administrator <a class='close' data-dismiss='alert'>&times; </a>  </div>";
        }
        else{
            //store the basic user data in variables
            if($row=mysqli_fetch_assoc($result)){
                $user=$row['email'];
                $password=$row['password'];
            }
            //verify whether hashed password and entered password matches
            
            if($password == $formPass){
                //correct login details
                //start the session
                session_start();
                
                //store the data in $_SESSION variable
                //never store the password in session array query it when required
                $_SESSION['loggedInUser']=$user;
                $_SESSION['loggedInEmail']=$email;
                
                //to go different page use header 
                //header is the address bar
                //syntax header("location:path");
                echo'<script>location.href="teacher/teacher_home.php"</script>';
               // header("location: https://google.co.in");
            }//end of password verified
            else{
                //password didnt verify
                $loginError="<br><div class='alert alert-danger'>Wrong Username Password Combination Please try again! <a class='close' data-dismiss='alert'>&times; </a>  </div>";
            }//end of password not verified
        }//end of if the num rows is 1
    }//if rows is greates than 0 ends
    else{
        $loginError="<br><div class='alert alert-danger'>No such user found in database. Please try again! <a class='close' data-dismiss='alert'>&times; </a>  </div>";
    }//end of 0 results fetched 
    mysqli_close($conn);
}//end of isset

?>
<div class="container" style="width:400px">
            
            <?php
            
            if($loginError){
                echo $loginError;
            }
            
            ?>
            <form class="form-vertical" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                <label class="text-danger">*<?php echo $itemsErr ?></label><br/>
                    
                        <label for="login-email" class="sr-only" style="color:white">Email</label>
                        <input type="text" name="email" id="login-email" placeholder="Email" class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please Enter the Email"><br>
                        <label for="login-password" class="sr-only">Password</label>
                        <input type="password" name="password" id="login-password" placeholder="Password" class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please Enter the Password"><br>
                <button name="login" class="btn btn-primary btn-lg">Login</button>
            </form>
</div>

                </div>
                
            </div>
        </div>

