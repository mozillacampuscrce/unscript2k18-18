<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
                <form  method="post" class="form-horizontal" role="form" enctype="multipart/form-data">
                
                <div class="form-group">
                    <label for="heading1" class="col-sm-3 control-label">Full Name</label>
                    <div class="col-sm-7">
                        <input type="text" id="FullName" name="name" placeholder="Full Name" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="heading1" class="col-sm-3 control-label">EMP_ID</label>
                    <div class="col-sm-7">
                        <input type="text" id="EMP_ID" name="EMP_ID" placeholder="Enter Emp_ID" class="form-control" autofocus required>
                


                        
                    </div>
                </div>
                
                
                
                <div class="form-group">
                    <label for="heading2" class="col-sm-3 control-label">Designation</label>
                    <div class="col-sm-7">
                        <input type="text" id="Designation" name="Designation" placeholder="Enter Designation" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="updateon" class="col-sm-3 control-label">Address</label>
                    <div class="col-sm-7">
                        <input type="textarea" id="Address" name="Address" placeholder="Enter Address" class="form-control" autofocus required>
                


                        
                    </div>
                </div>
                <div class="form-group">
                    <label for="updateon" class="col-sm-3 control-label">Upload Image</label>
                    <div class="col-sm-7">
                         <input type="file" name="UploadImage" id="UploadImage" required>
  



                        
                    </div>
                </div>
                                 
                <div class="form-group">
                    <label for="content" class="col-sm-3 control-label">Email ID</label>
                    <div class="col-sm-7">
                    <input type="email" id="EmailID" name="email" placeholder="Enter Email Id" class="form-control" autofocus required>
                        
                    </div>
                </div>
              
                <div class="form-group">
                    <label for="search" class="col-sm-3 control-label">Contact No.</label>
                    <div class="col-sm-7">
                        <input type="number" id="ContactNo." placeholder="Contact" class="form-control" name="ContactNo" autofocus>
                    </div>
                    </div>
                      <button type="submit" class="btn btn-primary" style="margin-left:26%">Add Prof.</button>
                    

            </form> 
    
    
    
    
    
    
    
</div>


<?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    
    include("includes/connection.php");
    $name = $_POST['name'];
    
    $email = $_POST['email'];

    $dpass="mars";
    $pid = uniqid();
    $addr = $_POST['addr'];
    
    $sql = "insert into teacher (name, email, password) values('$name','$email','$dpass')";
    
    mysqli_query($conn,$sql);
    
    
    
}
?>



<?php
include_once('includes/footer.php');
?>