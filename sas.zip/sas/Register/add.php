<?php 
    define('TITLE','ADD CLIENT');
    session_start();
    //check whether user gas logged in or not
    if(!$_SESSION['loggedInUser']){
        //send the user to login page
        header("location: index.php");
    }
    //connect to databse
    include_once('includes/connection.php');
    //include our custom function file
    include_once('includes/functions.php');
    //setting our error variables
    $nameError = $emailError = "";
    if(isset($_POST['add'])){
        //set all data variables to blank by default
        $clientName = $clientEmail = $clientPhone = $clientAddress = $clientCompany = $clientNotes = "";
        //check for any blank which are required
        if(!$_POST['clientName']){
            $nameError  = "Please Enter the name";
        }
        else{
            $clientName = validateFormData($_POST['clientName']);
        }
        if(!$_POST['clientEmail']){
            $emailError  = "Please Enter the Email<br>";
        }
        else{
            $clientEmail = validateFormData($_POST['clientEmail']);
        }
        //Following are not required so we can direcctly take them as it is
        
        $clientPhone = validateFormData($_POST['clientPhone']);
        $clientAddress = validateFormData($_POST['clientAddress']);
        $clientCompany = validateFormData($_POST['clientCompany']);
        $clientNotes = validateFormData($_POST['clientNotes']);
        
        //checking if there was error or not
        if($clientName && $clientEmail){
            $query = "INSERT INTO clients(name, email, phone, address, company, notes, created_at, updated_at) VALUES('$clientName','$clientEmail','$clientPhone','$clientAddress','$clientCompany','$clientNotes', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)";
            $result = mysqli_query($conn, $query);
            //check if queery was successfully executed!
            if($result){
                //refreshing clients.php with new data and with a queyr string
                header("location: clients.php?alert=success");
            }
            else{
                echo "Error: ".$query."<br>".mysqli_error($conn);
            }
        }
    }
    mysqli_close($conn);
    include_once('includes/header.php');
?>
<div class="container">
    <?php 
        if($nameError || $emailError){
    ?>
       <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
        </button>
        <strong>ERROR</strong><br/><?php echo $nameError.$emailError;?>
    </div>
<?php
    }
?>
    <h1>Add Cient</h1>    
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post" class="row">     
            <div class="form-group col-md-6">
            <label for="client-name">Name *</label>
            <input type="text" class="form-control input-lg" id="client-name" name="clientName">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Email *</label>
            <input type="email" class="form-control input-lg" id="client-email" name="clientEmail">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Phone</label>
            <input type="text" class="form-control input-lg" id="client-phone" name="clientPhone">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Address</label>
            <textarea class="form-control input-lg" id="client-address" name="clientAddress" row="5"></textarea>
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Company</label>
            <input type="text" class="form-control input-lg" id="client-company" name="clientCompany">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Notes</label>
            <input type="text" class="form-control input-lg" id="client-notes" name="clientNotes">
        </div>
        <div class="col-md-12">
            <a href="clients.php" type="button" class="btn btn-lg btn-warning">Cancel</a>
            <button type="submit" class="btn btn-lg btn-success pull-right" name="add">Add Client</button>
        </div>
    </form>

</div>
<?php 

    include_once('includes/footer.php');
?>
