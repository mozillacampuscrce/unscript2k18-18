<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
    <h1>Client Address Book</h1>
    
    <table class="table table-striped table-hover table-bordered table-responsive">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Address</th>
            <th>Company</th>
            <th>Notes</th>
            <th>Edit</th>
        </tr>
        <?php
            if(mysqli_num_rows($result)>0){
                //we have data to displpay
                
                while($row = mysqli_fetch_assoc($result))
                {
                    echo "<tr>";
                    echo "<td>".$row['name']."</td><td>".$row['email']."</td><td>".$row['phone']."</td><td>".$row['address']."</td><td>".$row['company']."</td><td>".$row['notes']."</td>";
                    
                    echo '<td><a href="edit.php?id='.$row['id'].'"
                    type="button" class="btn btn-primary">
                    <span class="glyphicon glyphicon-edit"></span></a></td>';
                    
                    echo"</tr>";
                }
            } else { //if no entries
                echo "<div class='alert alert-warning'>You have no clients!</div>";
            }
        ?>
        <tr>
            <td colspan="7">
                <div class="text-center">
                    <a href="add.php" type="button" class="btn btn-success">
                        <span class="glyphicon glyphicon-plus"></span>
                        Add Client
                    </a>
                </div>
            </td>
        </tr>
    </table>
</div>
<?php
include_once('includes/footer.php');
?>