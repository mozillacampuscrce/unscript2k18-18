<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM notices";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
    <h1>Notice Book</h1>
    
    <table class="table table-striped table-hover table-bordered table-responsive">
        <tr>
            <th>Name</th>
            <th>Title</th>
            <th>Date</th>
            <th>Discription</th>
        </tr>
        <?php
            if(mysqli_num_rows($result)>0){
                //we have data to displpay
                
                while($row = mysqli_fetch_assoc($result))
                {
                    echo "<tr>";
                    echo "<td>".$row['Nname']."</td><td>".$row['NoticeTitle']."</td><td>".$row['Edate']."</td><td>".$row['discription']."</td>";
                    
                    
                    
                    echo"</tr>";
                }
            } else { //if no entries
                echo "<div class='alert alert-warning'>You have no Notices!</div>";
            }
        ?>
        <tr>
            <td colspan="7">
                <div class="text-center">
                    <a href="../client/addnotice.php" type="button" class="btn btn-success">
                        <span class="glyphicon glyphicon-plus"></span>
                        Add Notice
                    </a>
                </div>
            </td>
        </tr>
    </table>
</div>
<?php
include_once('includes/footer.php');
?>