<?php

$server     ="localhost";
$username   ="staticco_test";
$password   ="admin@123!";
$db         ="staticco_test";

//create a connection
$conn = mysqli_connect($server, $username, $password, $db);

//check the connection
if(!$conn){
    die("connection Failed:". mysqli_connect_error());
}
//echo "Connected Successfully";

?>