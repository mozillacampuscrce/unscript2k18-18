<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');


include_once('includes/header.php');
?>
<div class="container">
    <h1>Order Summary</h1>
    <h3>Select Dates</h3>
    <form action="" method="POST">
        <input type="date" name="date1" class="form-control" style="width:15%"> <br/>
        <input type="date" name="date2" class="form-control" style="width:15%"> <br/>
        <button type="submit" value="show" name="show" class="btn btn-primary">Display</button>
    </form><br/>
    <?php
    if(isset($_POST['show']))
    {  
    ?>
    <table class="table table-striped table-hover table-bordered table-responsive">
        <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Item 1</th>
            <th>Item 2</th>
            <th>Item 3</th>
            <th>Total Bill</th>
            <th>Notes</th>
            <th>Date</th>
        </tr>
    
        <?php
            
                //query and result
                $query = "SELECT * FROM orders WHERE date BETWEEN CAST('$_POST[date1]' AS DATE) AND CAST('$_POST[date2]' AS DATE);";
                $result = mysqli_query($conn, $query);
                //mysqli_close($conn);

                if(mysqli_num_rows($result)>0){
                    //we have data to displpay

                    while($row = mysqli_fetch_assoc($result))
                    {
                        echo "<tr>";
                        echo "<td>".$row['name']."</td><td>".$row['addr']."</td><td>".$row['item1']."</td><td>".$row['item2']."</td><td>".$row['item3']."</td><td>".$row['total']."</td><td>".$row['note']."</td><td>".$row['date']."</td>";



                        echo"</tr>";
                    }
                } else { //if no entries
                    echo "<div class='alert alert-warning'>You have no sales between selected dates!</div>";
                }
        ?>
        <table class="table table-striped table-hover table-bordered table-responsive">
        <tr>
            <th>Name</th>
            <th>Total Bill</th>
<!--            <th>Date</th>-->
        </tr>
        <?php
                $total_bill="";
                $query1 = "SELECT name,total,date FROM orders WHERE date BETWEEN CAST('$_POST[date1]' AS DATE) AND CAST('$_POST[date2]' AS DATE);";
                $result1 = mysqli_query($conn, $query1);
                mysqli_close($conn);

                if(mysqli_num_rows($result)>0){
                    //we have data to displpay

                    while($row1 = mysqli_fetch_assoc($result1))
                    {
                        $total_bill += $row1['total'];
                        echo "<tr>";
                        echo "<td>".$row1['name']."</td><td>".$row1['total']."</td>";
                        echo"</tr>";  
                    }
                    echo "<tr>";
                            echo "<td><strong>Total Bill</strong></td>";
                            echo "<td>".$total_bill."</td>";
                        echo "</tr>";  
                } else { //if no entries
                    echo "<div class='alert alert-warning'>You have no sales between selected dates!</div>";
                }
            }
        ?>
        </table>
    </table>
</div>
<?php
include_once('includes/footer.php');
?>