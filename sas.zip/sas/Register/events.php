<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM events";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('../Register/includes/header.php');
?>
<div class="container">
    <h1>Event Book</h1>
    
    <table class="table table-striped table-hover table-bordered table-responsive">
        <tr>
            <th>Name</th>
            <th>InCharge</th>
            <th>Date</th>
            <th>Discription</th>
        </tr>
        <?php
            if(mysqli_num_rows($result)>0){
                //we have data to displpay
                
                while($row = mysqli_fetch_assoc($result))
                {
                    echo "<tr>";
                    echo "<td>".$row['Ename']."</td><td>".$row['Eincharge']."</td><td>".$row['Edate']."</td><td>".$row['discription']."</td>";
                    
                   
                    
                    echo"</tr>";
                }
            } else { //if no entries
                echo "<div class='alert alert-warning'>You have no Events!</div>";
            }
        ?>
        <tr>
            <td colspan="7">
                <div class="text-center">
                    <a href="../client/addevent.php" type="button" class="btn btn-success">
                        <span class="glyphicon glyphicon-plus"></span>
                        Add Event
                    </a>
                </div>
            </td>
        </tr>
    </table>
</div>
<?php
include_once('includes/footer.php');
?>