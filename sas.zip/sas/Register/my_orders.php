<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM orders";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
    <h1>Orders</h1>
    
    <table class="table table-striped table-hover table-bordered table-responsive">
        <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Item 1</th>
            <th>Item 2</th>
            <th>Item 3</th>
            <th>Total Bill</th>
            <th>Notes</th>
        </tr>
        <?php
            if(mysqli_num_rows($result)>0){
                //we have data to displpay
                
                while($row = mysqli_fetch_assoc($result))
                {
                    echo "<tr>";
                    echo "<td>".$row['name']."</td><td>".$row['addr']."</td><td>".$row['item1']."</td><td>".$row['item2']."</td><td>".$row['item3']."</td><td>".$row['total']."</td><td>".$row['note']."</td>";
                    
                   
                    
                    echo"</tr>";
                }
            } else { //if no entries
                echo "<div class='alert alert-warning'>You have no clients!</div>";
            }
        ?>
       
    </table>
</div>
<?php
include_once('includes/footer.php');
?>