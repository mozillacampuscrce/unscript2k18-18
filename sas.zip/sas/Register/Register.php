<?php
include_once('includes/header.php');
?> 
    <div class="container" id="main-container">
            <ul class="nav nav-tabs">
                <h3><li class="active"><a data-toggle="tab" href="#home">Sign In</a></li></h3>
<!--                <li><a data-toggle="tab" href="#Signup">Sign Up</a></li>-->
            </ul>   

              <div class="tab-content">
                <div id="home" class="tab-pane fade in active">
                    <?php include_once('index.php'); ?>
                </div>
                
<!--
                <div id="Signup" class="tab-pane fade">
                    <div>
                       <?php //include('insert.php'); ?>
                    </div>
                </div>
-->
            </div>
        </div>
<?php
    include_once('includes/footer.php');
?>       
    