<?php 
    $id=$_GET['id'];
    define('TITLE','ADD CLIENT');
    session_start();
    //check whether user gas logged in or not
    if(!$_SESSION['loggedInUser']){
        //send the user to login page
        header("location: index.php");
    }
    //connect to databse
    include_once('includes/connection.php');
    //include our custom function file
    include_once('includes/functions.php');
    //setting our error variables
    $nameError = $emailError = "";
    if(isset($_POST['delete'])){
        $deleteQuery = "DELETE FROM clients where id=$id";
        $delete = mysqli_query($conn, $deleteQuery);
        if($delete){
                //refreshing clients.php with new data and with a query string
                header("location: clients.php?alert=Dsuccess");
            }
            else{
                echo "Error: ".$query."<br>".mysqli_error($conn);
            }
    }
    if(isset($_POST['update'])){
        //set all data variables to blank by default
        $clientName = $clientEmail = $clientPhone = $clientAddress = $clientCompany = $clientNotes = "";
        //check for any blank which are required
        if(!$_POST['clientName']){
            $nameError  = "Please Enter the name";
        }
        else{
            $clientName = validateFormData($_POST['clientName']);
        }
        if(!$_POST['clientEmail']){
            $emailError  = "Please Enter the Email<br>";
        }
        else{
            $clientEmail = validateFormData($_POST['clientEmail']);
        }
        //Following are not required so we can direcctly take them as it is
        
        $clientPhone = validateFormData($_POST['clientPhone']);
        $clientAddress = validateFormData($_POST['clientAddress']);
        $clientCompany = validateFormData($_POST['clientCompany']);
        $clientNotes = validateFormData($_POST['clientNotes']);
        
        
        //checking if there was error or not
        if($clientName && $clientEmail){
            $query = "UPDATE clients set name='$clientName', email='$clientEmail', phone='$clientPhone', address='$clientAddress', company='$clientCompany', notes='$clientNotes', updated_at=CURRENT_TIMESTAMP where id=$id";
            $result = mysqli_query($conn, $query);
            //check if queery was successfully executed!
            if($result){
                //refreshing clients.php with new data and with a query string
                header("location: clients.php?alert=Usuccess&name=$clientName");
            }
            else{
                echo "Error: ".$query."<br>".mysqli_error($conn);
            }
        }
    }
    include_once('includes/header.php');
?>
<div class="container">
    <?php 
        if($nameError || $emailError){
    ?>
       <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;
        </button>
        <strong>ERROR</strong><br/><?php echo $nameError.$emailError;?>
    </div>
<?php
    }
?>
    <h1>Update Cient</h1> 
    
    <?php
        $selectQuery="select * from clients where id = $id";
        $selectUser= mysqli_query($conn, $selectQuery);
        while($row = mysqli_fetch_assoc($selectUser))
        {
            $name = $row['name'];
            $email = $row['email'];
            $phone = $row['phone'];
            $addr = $row['address'];
            $comp = $row['company'];
            $notes = $row['notes'];
        }
                    
    ?>   
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])."?id=$id";?>" method="post" class="row">     
            <div class="form-group col-md-6">
            <label for="client-name">Name *</label>
            <input type="text" class="form-control input-lg" id="client-name" name="clientName" value="<?php echo $name ?>">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Email *</label>
            <input type="email" class="form-control input-lg" id="client-email" name="clientEmail" value="<?php echo $email ?>">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Phone</label>
            <input type="text" class="form-control input-lg" id="client-phone" name="clientPhone" value="<?php echo $phone ?>">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Address</label>
            <textarea class="form-control input-lg" id="client-address" name="clientAddress" row="5"><?php echo $addr ?></textarea>
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Company</label>
            <input type="text" class="form-control input-lg" id="client-company" name="clientCompany" value="<?php echo $comp ?>">
        </div>
        <div class="form-group col-md-6">
            <label for="client-name">Notes</label>
            <input type="text" class="form-control input-lg" id="client-notes" name="clientNotes" value="<?php echo $notes ?>">
        </div>
        <div class="col-md-12">
                <button type="submit" class="btn btn-lg btn-danger" name="delete">Delete</button>
           <div class="pull-right">
               <button type="submit" class="btn btn-lg btn-success" name="update">Update</button>
                <a href="clients.php" type="button" class="btn btn-lg btn-warning">Cancel</a>
            </div>
        </div>
    </form>

</div>
<?php 

    include_once('includes/footer.php');
?>
