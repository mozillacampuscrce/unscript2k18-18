<?php

$server     ="localhost";
$username   ="staticco_test";
$password   ="admin@123!";
$db         ="staticco_test";

//create a connection
$conn = mysqli_connect("localhost","staticco_test","admin@123!","staticco_test");

//check the connection
if(!$conn){
    die("connection Failed:". mysqli_connect_error());
}
//echo "Connected Successfully";

?>