
<footer class="text-center">
    <hr>
        <label style="color:#555"> Coded with &hearts; by  </label> <a href="www.mywebsite.com">Mukesh Wadhwa</a>
</footer>


        <script src="//code.jquery.com/jquery-3.1.1.min.js"
  integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  crossorigin="anonymous"></script>
        
        <!-- Bootstrap JS -->
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
 </body>
</html>