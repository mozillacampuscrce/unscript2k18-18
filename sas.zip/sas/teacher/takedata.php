<?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
include("includes/connection.php");
//define vriables

$class=$_POST['branch'];

//Establish connection to database



//Query for selecting data from table
$sql = "select * from student where class='$class'";
$result = mysqli_query($conn,$sql);



?>



        <?php
            if(mysqli_num_rows($result)>0){
                //we have data to displpay
                
                while($row = mysqli_fetch_assoc($result))
                {
                    echo "<tr>";
                    echo "<td>".$row['name']."</td><td>".$row['rollno']."</td>
                    <td><div class='radio'>
  <label><input type='radio' name='optradio'>Option 1</label>
</div>
<div class='radio'>
  <label><input type='radio' name='optradio'>Option 2</label>
</div></td>";
                    
                    echo '<td><a href="edit.php?id='.$row['id'].'"
                    type="button" class="btn btn-primary">
                    <span class="glyphicon glyphicon-edit"></span></a></td>';
                    
                    echo"</tr>";
                }
            } else { //if no entries
                echo "<div class='alert alert-warning'>You have no clients!</div>";
            }
        ?>
       
    

<?php
}
?>