<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
    <form   method="post" class="form-horizontal" role="form">
    
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        
        
        <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Date</label>
                    <div class="col-sm-4">
                        <input type="date" id="Edate" name="Edate" placeholder="Edate" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
                
                
                  <div class="form-group">
                    <label for="class" class="col-sm-3 control-label">Class</label>
                        <div class="col-sm-4">
            
        
        
        
        
        
        <select class="form-control" name="branch">
            <option value="cm">CM</option>
            <option value="it">IT</option>
        
             
        </select>
        
        </div>
        </div>
                
        
        <div class="form-group">
                    <label for="class" class="col-sm-3 control-label">Subject</label>
                        <div class="col-sm-4">
            
        
        
        
        
        
        <select class="form-control" name="sub">
            <option value="spcc">SPCC</option>
            <option value="os">OS</option>
        
             
        </select>
        
        </div>
        </div>
                

                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Roll No</label>
                    <div class="col-sm-4">
                        <input type="text" id="rollno" name="rollno" placeholder="Roll Number" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="class" class="col-sm-3 control-label">Attendance</label>
                        <div class="col-sm-4">
            
        
        
        
        
        
        <select class="form-control" name="status">
            <option value="Absent">Absent</option>
            <option value="Present">Present</option>
        
             
        </select>
        
        </div>
        </div>
             
             
        </select>
        <div class="text-center" style="margin-top:20px">
                <Button type="submit" name = "takeattd" value="take_att" class="btn btn-success">Take Attendance</Button>
                </div>
        </div>
        </div>
        <div class="form-group">
                
</div>
</div>

</form>
<?php
// if(isset($_POST['takeattd'])){

// //define vriables

// $class=$_POST['branch'];
// $edate = $_POST['edate'];
// $sub = $_POST['sub'];


// //Establish connection to database



// //Query for selecting data from table
// $sql = "select * from student where class='$class'";
// $result = mysqli_query($conn,$sql);



?>

<form>

        
                
                
</form>


<?php
if(isset($_POST['takeattd'])){
    include("includes/connection.php");
    $status  = $_POST['status'];
    $sub  = $_POST['sub'];
    $date  = $_POST['Edate'];
    $class  = $_POST['branch'];
    $uuid  = "";
// Example 1
$stud  = $_POST['rollno'];
$sstud = explode(" ", $stud);




$array_string=mysql_escape_string(serialize($sstud));

    


$sql="INSERT INTO `attendance`(`name`, `att`, `date`, `sub`, `uuid`,class) VALUES ('$stud','$status','$date','$sub','$uuid','$class')";
//echo $sql;
    
    // $sql = "insert into atten (rollno,att) values('$stud','$att')";
    // echo $sql;
    
   if( mysqli_query($conn,$sql))
   {
    //   echo "success";
   }
    
}
    

?>


<?php
include_once('includes/footer.php');
?>