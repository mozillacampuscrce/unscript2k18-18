<?php
session_start();
//if(!isset($_SESSION['loggedInUser'])){
//    header("Location: Register.php");
//}
include('connection.php');
include_once('includes/header.php');
$nameErr=$addrErr=$itemsErr=$noteErr="";

if(isset($_POST["self_submit"]))
{
    

    function validateFormData($formData){
        $formData = trim(stripslashes(htmlspecialchars($formData)));
        return $formData;
    }
    //Setting all values to blank
    $name=$addr=$item1=$item2=$item3=$note="";
    if(!$_POST['name']){
        $nameErr = "Please enter the name";
    }
    else{
        $name = validateFormData($_POST['name']);
    }
    if(!$_POST['addr']){
        $addrErr = "Please enter the address";
    }
    else{
        $addr = validateFormData($_POST['addr']);
    }
//    if(!$_POST['item1']){
//        $itemsErr = "Blank order cannot be placed";
//    }
//    else{
//        $item1 = validateFormData($_POST['item1']);
//    }
    $item1 = validateFormData($_POST['item1']);
    $item2 = validateFormData($_POST['item2']);
    $item3 = validateFormData($_POST['item3']);
    if(!$_POST['note']){
        $noteErr = "Please Enter the note";
    }
    else{
        $note = validateFormData($_POST['note']);
    }
    if($name && $addr){
        $query = "insert into orders (name,addr,item1,item2,item3,total,note) values ('$name','$addr','$item1','$item2','$item3','$total','$note')";
        
        if(mysqli_query($conn,$query)){
            echo "<br/><div class='alert alert-success'>Order placed successfully ! Thank You ! </div>";
        }
        else{
            echo "<br/><div class='alert alert-danger'>".mysqli_error($conn)."</div>";
        }
    }
}
?>