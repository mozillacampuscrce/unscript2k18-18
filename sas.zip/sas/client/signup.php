<form action="Signup.php" method="POST">
                             <label class="text-danger">*<?php echo $nameError; ?></label>
                            <input type="text" name="sname" Placeholder="Name"><br><br>
                            <label class="text-danger">*<?php echo $emailError; ?></label>
                            <input type="email" name="semail" Placeholder="email"><br><br>
                            <label class="text-danger">*<?php echo $passwordError; ?></label>
                            <input type="password" name="spassword" Placeholder="Password"><br><br>
                            <button type="submit" name="self_submit" class="btn btn-primary">Sign Up</button>

                        </form>