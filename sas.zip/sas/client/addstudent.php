<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
    
    <form  method="post" class="form-horizontal" role="form">
            
            
            
            <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Student Name</label>
                    <div class="col-sm-4">
                        <input type="text" id="name" name="name" placeholder="Student Name" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
                
                
                            <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Roll No</label>
                    <div class="col-sm-4">
                        <input type="number" id="rollno" name="rollno" placeholder="Roll Number" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
            
            
            <div class="form-group">
                    <label for="class" class="col-sm-3 control-label">Class</label>
                        <div class="col-sm-4">
            
        
        
        
        
        
        <select class="form-control" name="branch">
            <option value="cm">CM</option>
            <option value="it">IT</option>
            <option value="extc">EXTC</option>
             <option value="etrx">ETRX</option>
             
        </select>
        
        </div>
        </div>
        
            
                
                
                
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Student Email</label>
                    <div class="col-sm-4">
                        <input type="text" id="email" name="email" placeholder="Student Email" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
                                
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Parent Email</label>
                    <div class="col-sm-4">
                        <input type="text" id="pemail" name="pemail" placeholder="Parent Email" class="form-control" autofocus required>
                        
                    </div>
                </div>
                
                
                
            
              
                
               <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">ADDRESS</label>
                    <div class="col-sm-4">
                    <input class="form-control" name="addr" rows="6" id="addr">
                        
                        
                    </div>
                </div>
                
                
                 <button type="submit" class="btn btn-primary"  style="margin-left:25%">ADD STUDENT</button>
                
                
                
        
    
    
    
                </div>
                <?php
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    
    include("includes/connection.php");
    $name = $_POST['name'];
    $rollno = $_POST['rollno'];
    $class = $_POST['branch'];
    $email = $_POST['email'];
    $pemail = $_POST['pemail'];
    $dpass="mars";
    $uuid = uniqid();
    $addr = $_POST['addr'];
    
    $sql = "insert into student (name, rollno, class,email,pemail,addr,uuid) values('$name','$rollno','$class','$email','$pemail','$addr','$uuid')";
    
    mysqli_query($conn,$sql);
    
     $sql1 = "insert into $class (email, password) values('$email','$dpass')";

    mysqli_query($conn,$sql1);
    
     $sql2 = "insert into parent (pemail, password,uuid) values('$pemail','$dpass','$uuid')";
    
    mysqli_query($conn,$sql2);
    
    
}
?>
                
                
                
                
                
<?php
include_once('includes/footer.php');
?>