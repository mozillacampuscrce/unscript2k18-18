<?php

//includes open the file and  copy it in the file
//includes_once only copies once


include('connection.php');

$nameError = $emailError = $passwordError = $dobError = "";
 if(isset($_POST['self_submit']))
    {
        //build a function that validates the data
        function validateFormData( $formData){
            $formData = trim(stripslashes(htmlspecialchars($formData)));
            return $formData;
        }
        //Setting all values to blank
        $name = $email = $password ="";
        //check for inputs
        if(!$_POST['name']){
            $nameError = "Please Enter a Name";
        }
        else{
            $name = validateFormData($_POST['name']);
        }
        if(!$_POST['email']){
            $emailError = "Please Enter a Email";
        }
//        if($_POST['email'])
//        {
//            $emailid=$_POST['email'];
//            $selectemail = mysql_query("select email from users where email='$emailid' ");
//            $count = mysql_num_rows($selectemail);
//            if($count == 0){
//                $emailError = "The Email you Entered is already Registered";
//            }
//        }
        else{
                $email = validateFormData($_POST['email']);
        }
        if(!$_POST['dob']){
            $dobError = "Please Enter a DOB";
        }
        else{
            $dob = validateFormData($_POST['dob']);
        }
        $date_b = $_POST['dob'];
        $da= substr($date_b,8,9);
        $mo= substr($date_b,-5,-3);
        $ye= substr($date_b,0,4);
        $check= $da.$mo.$ye;
        $checkPassword= $da.$mo.$ye.$email;
        $checkOther= $da.$mo.$ye.$name;
        $checkOneMore= $email.$name;
        $checkAnother= $name.$email;
        //$checkPassword = password_hash(validateFormData($check), PASSWORD_DEFAULT);
        if(!$_POST['password']){
            $passwordError = "Please Enter Password";
        }
        else if($_POST['password'] == $checkPassword || $_POST['password'] == $checkOther || $_POST['password'] == $checkOneMore || $_POST['password'] == $checkAnother || $_POST['password'] == $name || $_POST['password'] == $check)
        {
            $passwordError = "False Password";
        }
        else{
            $password = password_hash(validateFormData($_POST['password']), PASSWORD_DEFAULT);
        }
        //check if all the data are feeded or not
        if($name && $email && $dob && $password){
            $query = "Insert into Users(username,email,dob,password) values ('$name','$email','$dob','$password')";
            
            if(mysqli_query( $conn, $query)){
                echo "<br/><div class='alert alert-success'> New Record in Database ! </div> ";
            }
            else{
                echo "<div class='alert alert-danger'>".mysqli_error($conn)."</div>";
            }
        }
    }
?>
<!DOCTYPE html>

<html>

    <head>
        
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>MySql Insert</title>

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    
    <body>
        <div class="container" style="width:500px">
           
            <form class="form-vertical" action="<?php echo ($_SERVER['PHP_SELF']); ?>" method="POST">
                 <br><label class="text-danger">*<?php echo $nameError; ?></label>
                <input type="text" name="name" Placeholder="Name"class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please Enter the Username"><br>
                <label class="text-danger">*<?php echo $emailError; ?></label>
                <input type="email" name="email" Placeholder="email"class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please Enter the Email"><br>
                <label class="text-danger">*<?php echo $dobError; ?></label>
                <input type="date" name="dob" Placeholder=""class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please Enter the DOB"><br>
                <label class="text-danger">*<?php echo $passwordError; ?></label>
                <input type="password" name="password" Placeholder="Password"class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please Enter the Password"><br>
                <button type="submit" name="self_submit" class="btn btn-primary">Add Entry</button>
                
            </form>
        </div>
        
        <!-- jQuery -->
        <script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
        
        <!-- Bootstrap JS -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    </body>
</html>