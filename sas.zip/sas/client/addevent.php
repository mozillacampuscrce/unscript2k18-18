<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);

        $name = $_POST['Ename'];
        $Eincharge = $_POST['Eincharge'];
        $Edate = $_POST['Edate'];
        $discription = $_POST['discription'];
    if(isset($_POST['add']))
    {
        $query = "INSERT INTO `events` (Ename, Eincharge, Edate, discription) VALUES('$name','$Eincharge','$Edate','$discription')";
            $result = mysqli_query($conn, $query);
            //check if queery was successfully executed!
            if($result){
                //refreshing clients.php with new data and with a queyr string
              
            }
            else{
                echo "Error: ".$query."<br>".mysqli_error($conn);
            }
    }
include_once('../Register/includes/header.php');
?>
<div class="container">
   
    <form action="" method="post" class="form-horizontal" role="form">
            
            
            
            <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Event Name</label>
                    <div class="col-sm-4">
                        <input type="text" id="Ename" name="Ename" placeholder="Event Name" class="form-control" autofocus required>
                        
                    </div>
                </div>
               
                
              <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Event Incharge</label>
                    <div class="col-sm-4">
                        <input type="text" id="Eincharge" name="Eincharge" placeholder="Event Incharge" class="form-control" autofocus required>
                        
                    </div>
                </div>
             
        
                            <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Date</label>
                    <div class="col-sm-4">
                        <input type="date" id="Edate" name="Edate" placeholder="Event Date" class="form-control" autofocus required>
                        
                    </div>
                </div>

               <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Discription</label>
                    <div class="col-sm-4">
                    <input type="text" id="discription" name="discription" placeholder="discription" class="form-control" autofocus required>
                       
                    </div>
                </div>

                <button type="submit" name="add" class="btn btn-primary" style="margin-left:25%">Submit</button>
            </form> <!-- /form -->
        
    
    
    
    
    
    
</div>
<?php
include_once('includes/footer.php');
?>