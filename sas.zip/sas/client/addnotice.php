<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);

        $name = $_POST['Nname'];
        $NoticeTitle = $_POST['NoticeTitle'];
        $Edate = $_POST['Edate'];
        $discription = $_POST['discription'];
    if(isset($_POST['add']))
    {
        $query = "INSERT INTO `notices` (Nname, NoticeTitle, Edate, discription) VALUES('$name','$NoticeTitle','$Edate','$discription')";
            $result = mysqli_query($conn, $query);
            //check if queery was successfully executed!
            if($result){
                //refreshing clients.php with new data and with a queyr string
              
            }
            else{
                echo "Error: ".$query."<br>".mysqli_error($conn);
            }
    }
include_once('../Register/includes/header.php');
?>
<div class="container">
   
    <form action="" method="post" class="form-horizontal" role="form">
            
            
            
            <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label"> Name</label>
                    <div class="col-sm-4">
                        <input type="text" id="Nname" name="Nname" placeholder="Nname" class="form-control" autofocus required>
                        
                    </div>
                </div>
              <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Notice Title</label>
                    <div class="col-sm-4">
                        <input type="text" id="NoticeTitle" name="NoticeTitle" placeholder="Notice Title" class="form-control" autofocus required>
                        
                    </div>
                </div>
                            <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Date</label>
                    <div class="col-sm-4">
                        <input type="date" id="Edate" name="Edate" placeholder="Edate" class="form-control" autofocus required>
                        
                    </div>
                </div>
               <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Discription</label>
                    <div class="col-sm-4">
                    <input type="text" id="discription" name="discription" placeholder="discription" class="form-control" autofocus required>
                        
                        
                    </div>
                </div>
               <button type="submit" name="add" class="btn btn-primary">Post Notice</button>
            </form> <!-- /form -->
</div>
<?php
include_once('includes/footer.php');
?>