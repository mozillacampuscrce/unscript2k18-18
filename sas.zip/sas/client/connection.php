<?php

$server = "localhost";
$username = "mukesh";
$password = "123456";
$db       = "tutorials";

//establishing a connection

$conn = mysqli_connect($server,$username,$password,$db);

if($conn){
  
}
else{
    die("Connection Error".mysqli_connect_error());
}
//echo "Connected Successfully";