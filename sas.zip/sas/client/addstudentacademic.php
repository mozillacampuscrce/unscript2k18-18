<?php

session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM clients";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
 
 
 
 
 
 
 
</div>
<?php
include_once('includes/footer.php');
?>