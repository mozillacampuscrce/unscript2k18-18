<?php
session_start();
//if(!isset($_SESSION['loggedInUser'])){
//    header("Location: Register.php");
//}
include('connection.php');
include_once('includes/header.php');
$nameErr=$addrErr=$itemsErr=$noteErr="";
$flag=0;
if(isset($_POST["self_submit"]))
{
    

    function validateFormData($formData){
        $formData = trim(stripslashes(htmlspecialchars($formData)));
        return $formData;
    }
    //Setting all values to blank
    $name=$addr=$item1=$item2=$item3=$note="";
    
    $name = validateFormData($_SESSION['loggedInUser']);
    
    
    if(!$_POST['addr']){
        $addrErr = "Please enter the address";
        $flag=0;
    }
    else{
        $addr = validateFormData($_POST['addr']);
        $flag=1;
    }
//    if(!$_POST['item1']){
//        $itemsErr = "Blank order cannot be placed";
//    }
//    else{
//        $item1 = validateFormData($_POST['item1']);
//    }
    $item1 = validateFormData($_POST['item1']);
    $item2 = validateFormData($_POST['item2']);
    $item3 = validateFormData($_POST['item3']);
    if(!$_POST['note']){
        $noteErr = "Please Enter the note";
        $flag=0;
    }
    else{
        $note = validateFormData($_POST['note']);
        $flag=1;
    }
    
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Placing order</title>
        
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
    </head>
    <body>
       
        <div class="container" id="main-container" style="width:500px">
            <ul class="nav nav-tabs">
                <h3><li class="active"><a data-toggle="tab" href="#home">Enter Order Details</a></li></h3>
                <label class="text-danger">Once you clicked on generate bill, cannot be changed</label>
            </ul>   
            <div class="tab-content">
                <div id="home" class="tab-pane fade in active">
                    <form class="form-vertical" action="" method="POST">
<!--                        <br/><label class="text-danger">*<?php echo $nameErr; ?></label>-->
                        <input type="text" name="name" class="form-control" value="<?php echo $_SESSION['loggedInUser']; ?>" disabled><br/>
                        <label class="text-danger">*<?php echo $addrErr ?></label>
                        <input type="text" name="addr" placeholder="Address" class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please enter the address"><br/>
<!--                        <label class="text-danger">*<?php echo $itemsErr ?></label><br/>-->
                        <select name="item1" class="form-control" class="col">
                            <option value="0">Select Item 1</option>
                            <option value="Wheat">Wheat-200</option>
                            <option value="Rice">Rice-100</option>
                            <option value="Cashewnuts">Cashewnuts-300</option>
                            <option value="Almonds">Almonds-400</option> 
                        </select><br/>
                        <select name="item2" class="form-control" class="col">
                            <option value="0">Select Item 2</option>
                            <option value="Maggi">Maggi-75</option>
                            <option value="Oats Meal">Oats Meal-87</option>
                            <option value="Oats Digestive Cookies">Oats Digestive Cookies-60</option>
                            <option value="Oreo Big Pack">Oreo Big Pack-40</option> 
                        </select><br/>
                        <select name="item3" class="form-control" class="col">
                            <option value="0">Select Item 3</option>
                            <option value="Milk">Milk-44</option>
                            <option value="Tea">Tea-108</option>
                            <option value="Sugar">Sugar-45</option>
                            <option value="Bread">Bread-23</option> 
                        </select><br/>
<!--
                        <div class="form-check">
                            <input type="checkbox" name="items[]" value="Rice-100" class="form-check-input" style="display:inline"><label>Rice</label><br/>
                            <input type="checkbox" name="items[]" value="Wheat-200" class="form-check-input"><label>Wheat</label><br/>
                            <input type="checkbox" name="items[]" value="Almonds-800" class="form-check-input"><label>Almonds</label><br/>
                        </div>    
-->
                        <label class="text-danger">*<?php echo $noteErr ?></label>
                        <input type="text" name="note" placeholder="Notes" class="form-control" data-toggle="tooltip" data-placement="bottom" title="Please enter the note if any or type none"><br/>
                        <button type="submit" name="self_submit" class="btn btn-primary">Generate Bill</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- jQuery -->
        <script src="//code.jquery.com/jquery-2.1.4.min.js"></script>
        
        <!-- Bootstrap JS -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
    </body>
</html>
<?php
if(isset($_POST["self_submit"]))
{
    $price1=$price2=$price3=$total="";
    $item="item";
//    for($i=1;$i<=3;$i++)
//    {
//        $sql = "select price from billing where item_name='$item.$i'";
//        $ans = mysqli_query($conn,$sql);
//      
//        echo "Hello";
//        if(mysqli_num_rows($ans)>0)
//        {
//            while($row = mysqli_fetch_assoc($ans))
//            {
//                $price.$i=$row['price'];     
//                echo $price.$i;
//            }
//        }
//    }
        $sql = "select price from billing where item_name='$item1'";
        $ans = mysqli_query($conn,$sql);
        if(mysqli_num_rows($ans)>0)
        {
            while($row = mysqli_fetch_assoc($ans))
            {
                $price1=$row['price'];     
            }
        }
        $sql = "select price from billing where item_name='$item2'";
        $ans = mysqli_query($conn,$sql);
      
        if(mysqli_num_rows($ans)>0)
        {
            while($row = mysqli_fetch_assoc($ans))
            {
                $price2=$row['price'];     
            }
        }
        $sql = "select price from billing where item_name='$item3'";
        $ans = mysqli_query($conn,$sql);
    
        if(mysqli_num_rows($ans)>0)
        {
            while($row = mysqli_fetch_assoc($ans))
            {
                $price3=$row['price'];     
            }
        }
    //echo $row['price'];
    $total=$price1+$price2+$price3;
?>
    <div class="container">
        <h1>Your Orders</h1>

        <table class="table table-striped table-hover table-bordered table-responsive">
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Item 1</th>
                <th>Item 2</th>
                <th>Item 3</th>
                <th>Total</th>
                <th>Note</th>
            </tr>
            <?php
    //            if(mysqli_num_rows($result)>0){
    //                //we have data to displpay
    //                
    //                while($row = mysqli_fetch_assoc($result))
    //                {
                        echo "<tr>";
                        echo "<td>".$_SESSION['loggedInUser']."</td><td>".$addr."</td><td>".$item1."</td><td>".$item2."</td><td>".$item3."</td><td>".$total."</td><td>".$note."</td>";

    //                    echo '<td><a href="edit.php?id='.$row['id'].'"
    //                    type="button" class="btn btn-primary">
    //                    <span class="glyphicon glyphicon-edit"></span></a></td>';

                        echo"</tr>";
    //                }
    //            } else { //if no entries
    //                echo "<div class='alert alert-warning'>You have no orders!</div>";
    //            }
            ?>
            <tr>
                <td colspan="7">
                    <div class="text-center">
                       <form action="" method="POST">
                        <button type="submit" value="order" name="order" class="btn btn-primary">
                            <span class="glyphicon glyphicon-plus"></span>
                            Place Order
                        </button>
                        </form>
                    </div>
                </td>
            </tr>
        </table>
    </div>    

<?php
    }
//    $adr=$_POST['addr'];
//    $items1=$_POST['item1'];
//    $items2=$_POST['item2'];
//    $items3=$_POST['item3'];
//    $totals=$total;
//    $notes=$_POST['note'];
    if(isset($_POST["self_submit"]))
    {
//        $addr=$_POST[];
//        $item1=$item2=$item3=$note=$total="";
        //echo "Hello";
        if($flag==1){
        $query = "insert into orders (name,addr,item1,item2,item3,total,note,date) values ('$_SESSION[loggedInUser]','$addr','$item1','$item2','$item3','$total','$note',CURRENT_TIMESTAMP)";
        
        if(mysqli_query($conn,$query)){
//            echo "<br/><div class='alert alert-success'>Order placed successfully ! Thank You ! </div>";
        }
        else{
            echo "<br/><div class='alert alert-danger'>".mysqli_error($conn)."</div>";
        }
        }
    }
    if(isset($_POST["order"]))
    {
        //  echo "<br/><div class='alert alert-success'>Order placed successfully ! Thank You ! </div>";
    }
    include_once('includes/footer.php');
?>