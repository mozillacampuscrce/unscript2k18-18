<?php
    session_start();
if(!isset($_SESSION['loggedInUser'])){
    //send them to login page
    header("Location: index.php");
}
//connect to the database
include('includes/connection.php');

//query and result
$query = "SELECT * FROM orders where name='$_SESSION[loggedInUser]'";
$result = mysqli_query($conn, $query);
mysqli_close($conn);
include_once('includes/header.php');
?>
<div class="container">
    <h1>Your Orders</h1>
    
    <table class="table table-striped table-hover table-bordered table-responsive">
        <tr>
            <th>Name</th>
            <th>Address</th>
            <th>Item 1</th>
            <th>Item 2</th>
            <th>Item 3</th>
            <th>Note</th>
        </tr>
        <?php
//            if(mysqli_num_rows($result)>0){
//                //we have data to displpay
//                
//                while($row = mysqli_fetch_assoc($result))
//                {
                    echo "<tr>";
                    echo "<td>".$_POST['name']."</td><td>".$_POST['addr']."</td><td>".$_POST['item1']."</td><td>".$_POST['item2']."</td><td>".$_POST['item3']."</td><td>".$_POST['note']."</td>";
                    
//                    echo '<td><a href="edit.php?id='.$row['id'].'"
//                    type="button" class="btn btn-primary">
//                    <span class="glyphicon glyphicon-edit"></span></a></td>';
                    
                    echo"</tr>";
//                }
//            } else { //if no entries
//                echo "<div class='alert alert-warning'>You have no orders!</div>";
//            }
        ?>
        <tr>
            <td colspan="7">
                <div class="text-center">
                    <a href="order_place.php" type="button" class="btn btn-success">
                        <span class="glyphicon glyphicon-plus"></span>
                        Place Order
                    </a>
                </div>
            </td>
        </tr>
    </table>
</div>
